<?php

# Load an example-spark library
$autoload['libraries'] = array('example_spark');
